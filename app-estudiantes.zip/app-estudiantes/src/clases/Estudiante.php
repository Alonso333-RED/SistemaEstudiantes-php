<?php
class Estudiante{
    public int $estudiante_id;
    public string $nombre;
    public string $apellido1;
    public string $apellido2;
    public string $run;
    public string $curso; 
}